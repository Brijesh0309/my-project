import { test, expect } from '@playwright/test';

test('Login and verify dashboard', async ({ page }) => {

  // Open login page
  await page.goto('http://localhost:8000/login');

  // Wait for page load
  await page.waitForLoadState('networkidle');

  // Fill mobile number
  await page.getByPlaceholder('Enter mobile number')
    .fill('9876543210');

  // Fill password
  await page.getByPlaceholder('Enter password')
    .fill('password123');

  // Click login button
  await page.locator("//form//button").click();

  // Stop execution here for debugging
  await page.pause();

  // Print current URL
  console.log("Current URL:", await page.url());

  // Verify dashboard URL
  await expect(page).toHaveURL(/dashboard/);

});