import { test, expect } from '@playwright/test';

test('Update Profile', async ({ page }) => {

  // Open Login Page
  await page.goto('http://localhost:8000/login');

  // Login
  await page.getByPlaceholder('Enter mobile number')
    .fill('9876543210');

  await page.getByPlaceholder('Enter password')
    .fill('password123');

  await page.locator("//form//button").click();

  // Wait for dashboard
  await page.waitForURL('**/dashboard');

  // Click Profile Menu
  await page.getByText('Profile').click();

  // Wait for Profile Page
  await page.waitForURL('**/profile');

  // Verify Profile Heading
  await expect(
    page.getByRole('heading', { name: 'Profile Settings' })
  ).toBeVisible();

  // Update Full Name
  const fullName = page.locator('input').nth(0);

  await fullName.clear();

  await fullName.fill('Rahul Sharmaa');

  // Update Email
  const email = page.locator('input').nth(1);

  await email.clear();

  await email.fill('rahul@example.com');

  // Update Mobile Number
  const mobile = page.locator('input').nth(2);

  await mobile.clear();

  await mobile.fill('9876543210');

  // Update PAN Number
  const pan = page.locator('input').nth(3);

  await pan.clear();

  await pan.fill('ABCDE1234F');

  // Click Update Profile Button
  await page.getByRole('button', {
    name: 'Update Profile'
  }).click();

  // Wait after update
  await page.waitForTimeout(3000);

  // Verify Updated Values
  await expect(fullName)
    .toHaveValue('Rahul Sharmaa');

  await expect(email)
    .toHaveValue('rahul@example.com');

  await expect(mobile)
    .toHaveValue('9876543210');

  await expect(pan)
    .toHaveValue('ABCDE1234F');

  // Hold browser
  await page.waitForTimeout(5000);

});