import { test, expect } from '@playwright/test';
import promptSync from 'prompt-sync';

const prompt = promptSync();



// =====================================
// TAKE USER INPUT FROM TERMINAL
// =====================================

const mobileNumber = prompt('Enter Mobile Number: ');
const operator = prompt('Enter Operator (Jio/Airtel/Vi): ');
const amount = prompt('Enter Recharge Amount: ');

test('Login and make recharge transaction', async ({ page }) => {

  // =====================================
  // LOGIN
  // =====================================

  await page.goto('http://localhost:8000/login');

  await page.waitForLoadState('domcontentloaded');

  // Wait before entering login mobile number
  await page.waitForTimeout(2000);

  // Clear and enter login mobile number
  const loginMobile = page.getByPlaceholder('Enter mobile number');

  await loginMobile.clear();

  await loginMobile.fill('9876543210');

  // Wait before entering password
  await page.waitForTimeout(2000);

  // Clear and enter password
  const passwordInput = page.getByPlaceholder('Enter password');

  await passwordInput.clear();

  await passwordInput.fill('password123');

  // Wait before clicking login
  await page.waitForTimeout(2000);

  // Click login button
  await page.locator("//form//button").click();

  // Wait for dashboard page
  await page.waitForURL('**/dashboard');

  // Verify dashboard heading
  await expect(
    page.getByRole('heading', { name: 'Dashboard' })
  ).toBeVisible();

  // =====================================
  // OPEN RECHARGE PAGE
  // =====================================

  await page.waitForTimeout(2000);

  // Click New Recharge button
  await page.getByText('New Recharge').click();

  // Wait for recharge page
  await page.waitForURL('**/recharge');

  // Verify recharge heading
  await expect(
    page.getByRole('heading', { name: 'Mobile Recharge' })
  ).toBeVisible();

  // =====================================
  // FILL RECHARGE FORM
  // =====================================

  // Wait before entering mobile number
  await page.waitForTimeout(2000);

  // Mobile Number
  const mobileInput = page.getByPlaceholder('Enter mobile number');

  await mobileInput.clear();

  await mobileInput.fill(mobileNumber);

  // Wait before selecting operator
  await page.waitForTimeout(2000);

  // Operator
  await page.locator('select')
    .selectOption({ label: operator });

  // Wait before entering amount
  await page.waitForTimeout(2000);

  // Amount
  const amountInput = page.getByPlaceholder('Enter amount');

  await amountInput.clear();

  await amountInput.fill(amount);

  // =====================================
  // CLICK RECHARGE BUTTON
  // =====================================

  await page.waitForTimeout(2000);

  await page.getByRole('button', {
    name: 'Recharge Now'
  }).click();

  // =====================================
  // VERIFY SUCCESS
  // =====================================

  await page.waitForTimeout(3000);

  // Verify recharge details
  await expect(page.locator('body'))
    .toContainText(mobileNumber);

  await expect(page.locator('body'))
    .toContainText(amount);

  // Hold browser
  await page.waitForTimeout(5000);

});