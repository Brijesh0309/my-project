import { test, expect } from '@playwright/test';

test('Login with valid credentials', async ({ page }) => {

  // Open website
  await page.goto('http://localhost:8000/login');

  // Wait for page to load completely
  await page.waitForLoadState('networkidle');


  await page.getByPlaceholder('Enter mobile number').fill('9876543210');


  await page.getByPlaceholder('Enter password').fill('password123');

  // Click login
 // await page.click('button[type="submit"]');
 await page.locator("//form//button").click();

  // Verify dashboard URL
  await expect(page).toHaveURL(/dashboard/);

  // Hold page for 40 seconds
  await page.waitForTimeout(40000);

});